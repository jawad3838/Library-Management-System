from django.apps import AppConfig


class BookmanagementConfig(AppConfig):
    name = 'bookManagement'
