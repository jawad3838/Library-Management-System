
from django.db import models

# Create your models here.
class Books(models.Model):
    BookIban = models.CharField(max_length=200)
    BookName  = models.CharField(max_length=200)
    AuthorName = models.CharField(max_length=200)

class students(models.Model):
    book_id = models.ForeignKey(Books, on_delete=models.CASCADE)
    SName = models.CharField(max_length=200)
    BookIssued  = models.CharField(max_length=200)
    Date = models.CharField(max_length = 200)
