from django.shortcuts import render
from .models import Books, students
from django.http import HttpResponse

def index(request):
    b = Books.objects.all()
    s = students.objects.all()
    return render(request,'bookManagement/index.html',{'b':b,'s':s})
